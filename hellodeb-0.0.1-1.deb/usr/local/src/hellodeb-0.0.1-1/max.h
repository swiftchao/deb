/*************************************************************************
    > File Name: max.h
    > Author: chaofei
    > Mail: chaofeibest@163.com 
    > Created Time: 2019-03-17 04:26:37
 ************************************************************************/

#ifndef _MAX_H_
int max(int a, int b);
#define _MAX_H_
#endif
