/*************************************************************************
    > File Name: swap.h
    > Author: chaofei
    > Mail: chaofeibest@163.com 
    > Created Time: 2019-03-17 04:24:06
 ************************************************************************/

#ifndef _SWAP_H_
#define _SWAP_H_
void swap(int *x, int *y);
#endif
